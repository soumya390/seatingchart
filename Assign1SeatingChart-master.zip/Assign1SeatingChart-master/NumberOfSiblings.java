import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of interface NumberOfSiblings here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface NumberOfSiblings 
{
    // method signatures - implement the signature below in your own class. Make sure to
    //                     match the parameter list and return type
    public int numberOfSiblings();
    public int numberOfBrothers();
    public int numberOfSisters();
    
}
